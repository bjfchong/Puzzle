public class Dual {
	private int a;
	private int b;
	private int c;
	private int d;
	private int tileNumL;
	private int tileNumR;
	
	public Dual (int tileNumL, int tileNumR, int a, int b, int c, int d){
		setDualEdges(a,b,c,d);
		setTileNums(tileNumL,tileNumR);
	}
	
	public void setDualEdges(int a, int b, int c, int d){
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}
	
	public void setTileNums(int tileNumL, int tileNumR){
		this.tileNumL = tileNumL;
		this.tileNumR = tileNumR;
	}
	
	public int getA(){
		return a;
	}
	
	public int getB(){
		return b;
	}
	
	public int getC(){
		return c;
	}
	
	public int getD(){
		return d;
	}
	
	public int getTileNumL(){
		return tileNumL;
	}
	
	public int getTileNumR(){
		return tileNumR;
	}
	
	public static void main(String[] args){
		
	}
}