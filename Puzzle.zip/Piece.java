public class Piece {
	
	private int a;
	private int b;
	private int c;
	private int d;
	private int tileNum;
	
	
	// a - top, b - right, c - bottom, d - left
	//num, denotes piece number 1 - 16

	public Piece (int tileNum, int a, int b, int c, int d){
		setEdges(a,b,c,d);
		setTileNum(tileNum);
	}
	
	
	public void setEdges(int a, int b, int c, int d){
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}
	
	public void setTileNum(int tileNum){
		this.tileNum = tileNum;
	}
	
	
	
	//returns what shape lies on that edge 
	
	public int getA(){
		return a;
	}
	
	public int getB(){
		return b;
	}
	
	public int getC(){
		return c;
	}
	
	public int getD(){
		return d;
	}
	
	public int getTileNum(){
		return tileNum;
	}
	
	public static void main(String[] args){
		
	}
}