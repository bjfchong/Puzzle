import java.util.Scanner;
import java.io.IOException;

public class Solver {
	
	public static int pieceNumber = 16;
	public static Piece[] initialPieceArray = new Piece[pieceNumber];
	public static Piece[] allPieceArray = new Piece[pieceNumber*4];
	public static int doubleCount = 0;
	public static int[][] dualTileNums = new int[2][488];
	public static int[][] quadTileNums = new int[4][5454];
	public static int[][] halfTileNums = new int[8][81824];
	public static int quadTileCount = 0;
	public static int halfTileCount = 0;
	public static int solutionCount = 0;
	public static Dual[] dualList = new Dual[doubleCount];
	public static int[][] halfSols = new int[50000][2];
	
	public static boolean samePieceChecker(Piece A, Piece B){
		if (((int)A.getTileNum()) == (int)(B.getTileNum()/4)){
			return true;
		} else {
			return false;
		}
	}
	
	public static boolean sameQuadChecker(int A, int B){
	
		int[] quad1 = new int[4];
		int[] quad2 = new int[4];
	
		for (int i = 0; i<4;i++){
			quad1[i] = quadTileNums[i][A];
			quad2[i] = quadTileNums[i][B];
		}
		
		//screens out error where a quad with all 0s was being used
		int zeroCount = 0;
		for (int z =0;z<4;z++){
			if (quad1[z] == 0){
				zeroCount++;
			}
			if (quad2[z] == 0){
				zeroCount++;
			}
			if (zeroCount > 1){
				return false;
			}
		}
		
		for (int m  = 0; m<4; m++){
			for (int n  = 0; n<4; n++){
				if((int)(quad2[m]/4) == (int)(quad1[n]/4)){
					return false;
				} 
			}	
		}
		
		return true;
	}
	
	public static boolean sameDualChecker(int A, int B){
	
		int[] dual1 = new int[2];
		int[] dual2 = new int[2];
	
		for (int i = 0; i<2;i++){
			dual1[i] = dualTileNums[i][A];
			dual2[i] = dualTileNums[i][B];
		}
		
	
		
		for (int m  = 0; m<2; m++){
			for (int n  = 0; n<2; n++){
				if((int)(dual2[m]/4) == (int)(dual1[n]/4)){
					return false;
				} 
			}	
		}
		
		return true;
	}
	
	public static boolean quadFitChecker(int A, int B){
		int[] quad1 = new int[4];
		int[] quad2 = new int[4];
	
		for (int i = 0; i<4;i++){
			quad1[i] = quadTileNums[i][A];
			quad2[i] = quadTileNums[i][B];
		}
		
		if (allPieceArray[quad1[1]].getB() + allPieceArray[quad2[0]].getD() == 0 && allPieceArray[quad1[2]].getB() + allPieceArray[quad2[3]].getD() == 0){
			if(allPieceArray[quad1[1]].getB() != 0 && allPieceArray[quad2[0]].getD()!= 0 && allPieceArray[quad1[2]].getB() != 0 &&  allPieceArray[quad2[3]].getD() != 0){
				return true;
			}
			
		} 
		
		return false;

	}
	
	public static void loadPieces(){
		
		try{
			load file = new load("Pieces");
			String[] pieceLoader = file.OpenFile();
			
			int a = 0;
			int b = 0;
			int c = 0;
			int d = 0;
			
			
			for (int i = 0; i < pieceNumber; i++){
				
				String[] splitter = pieceLoader[i].split("\\.");
				
				Piece temp = new Piece(0,a,b,c,d);
				temp.setEdges(Integer.parseInt(splitter[0]),Integer.parseInt(splitter[1]),Integer.parseInt(splitter[2]),Integer.parseInt(splitter[3]));
				temp.setTileNum(i);
				initialPieceArray[i] = temp;
				
			}
			
		} catch (IOException e ){
			System.out.println("fail");
		}
	}

	public static void spinPieces(){
		for (int i = 0; i < pieceNumber;i++){
			
			Piece origPiece = initialPieceArray[i];
			allPieceArray[i*4] = initialPieceArray[i];
			
			
			allPieceArray[i*4 + 1] = new Piece(i,origPiece.getB(),origPiece.getC(), origPiece.getD(), origPiece.getA());
			allPieceArray[i*4 + 2] = new Piece(i,origPiece.getC(),origPiece.getD(), origPiece.getA(), origPiece.getB());
			allPieceArray[i*4 + 3] = new Piece(i,origPiece.getD(),origPiece.getA(), origPiece.getB(), origPiece.getC());
			
		}
		
	}
	
	public static void listMatches(){
		int quick = 0;
		
		for (int i = 0; i < allPieceArray.length;i++){
			for (int j = 0; j < allPieceArray.length; j++){
				if ((int)(i/4) != (int)(j/4)){
					if(allPieceArray[i].getB() + allPieceArray[j].getD() == 0){
						//System.out.print(i + " "  + j);
						//System.out.print(" | ");
						dualTileNums[0][doubleCount] = i;
						dualTileNums[1][doubleCount++] = j;
					}				
				}
			}
		}
	}
	
	public static Dual[] makeDuals(){
		Dual[] dualArray = new Dual[doubleCount];
		//System.out.println(doubleCount);																										
		
		
		
		for (int i = 0;i<doubleCount;i++){
			
			
			//the number stored in dualTileNums is for the orientation as well, ie 37 etc, 0-63.
			dualArray[i] = new Dual(dualTileNums[0][i],dualTileNums[1][i],allPieceArray[dualTileNums[0][i]].getA(),allPieceArray[dualTileNums[1][i]].getA(),allPieceArray[dualTileNums[1][i]].getC(),allPieceArray[dualTileNums[0][i]].getC());
			
		}
		return dualArray;
	}
	
	public static void pairDuals(Dual[] list){
		for (int i = 0;i<list.length;i++){
			for (int j = 0;j<list.length;j++){
				if (sameDualChecker(i,j)){
					if(list[i].getD() + list[j].getA() == 0 && list[i].getC() + list[j].getB() == 0){
						quadTileNums[0][quadTileCount] = list[i].getTileNumL();
						quadTileNums[1][quadTileCount] = list[i].getTileNumR();
						quadTileNums[2][quadTileCount] = list[j].getTileNumR();
						quadTileNums[3][quadTileCount++] = list[j].getTileNumL();
					}
				}
			}
		}
	}
	
	public static void pairQuads(){
		for (int i = 0;i<3660;i++){
			for (int j = 0;j<3660;j++){
				if (sameQuadChecker(i,j) && quadFitChecker(i,j)){
					halfTileNums[0][halfTileCount] = quadTileNums[0][i];
					halfTileNums[1][halfTileCount] = quadTileNums[1][i];
					halfTileNums[2][halfTileCount] = quadTileNums[0][j];
					halfTileNums[3][halfTileCount] = quadTileNums[1][j];
					halfTileNums[4][halfTileCount] = quadTileNums[3][i];
					halfTileNums[5][halfTileCount] = quadTileNums[2][i];
					halfTileNums[6][halfTileCount] = quadTileNums[3][j];
					halfTileNums[7][halfTileCount++] = quadTileNums[2][j];	
					
					if (halfTileCount == 7996) {
						//System.out.println(i + "," + j);
					}
					
				}
			}
		}
	}
	
	public static boolean halfFitChecker(int A, int B){
		int[] half1 = new int[8];
		int[] half2 = new int[8];
	
		for (int i = 0; i<8;i++){
			half1[i] = halfTileNums[i][A];
			half2[i] = halfTileNums[i][B];
		}
		
		if (allPieceArray[half1[4]].getC() + allPieceArray[half2[0]].getA() == 0 && allPieceArray[half1[5]].getC() + allPieceArray[half2[1]].getA() == 0 && allPieceArray[half1[6]].getC() + allPieceArray[half2[2]].getA() == 0 && allPieceArray[half1[7]].getC() + allPieceArray[half2[3]].getA() == 0){
			boolean allZero = false;
			int zeroCount = 0;
			for (int j = 0;j<8;j++){
				if (half1[j] == 0){
					zeroCount++;
				}
				if (half2[j] == 0){
					zeroCount++;
				}				
			}
			if(zeroCount < 2){
				return true;
			}	
				
		} 
		
		return false;

	}
	
	public static boolean sameHalfChecker(int A, int B){
	
		int[] half1 = new int[8];
		int[] half2 = new int[8];
	
		for (int i = 0; i<8;i++){
			half1[i] = halfTileNums[i][A];
			half2[i] = halfTileNums[i][B];
		}
	
		for (int m  = 0; m<8; m++){
			for (int n  = 0; n<8; n++){
				if((int)(half2[m]/4) == (int)(half1[n]/4)){
					return false;
				} 
			}	
		}
		
		return true;
	}
	
	public static void pairHalves(){
		for (int i = 0;i<81824;i++){
			for (int j = 0;j<81824;j++){
				if (sameHalfChecker(i,j) && halfFitChecker(i,j)){
					solutionCount++;
					halfSols[solutionCount][0] = i;
					halfSols[solutionCount][1] = j;
					System.out.println(solutionCount + ") Half: " + i + " and half: " + j);
				}
			}
			if (solutionCount == 48){
				break;
			}
		}
	}

	
	public static  void testQuads(){
		int runningCount = 0;
		for(int i = 0;i<quadTileNums.length;i++){
			runningCount = runningCount + (allPieceArray[quadTileNums[0][i]].getB() + allPieceArray[quadTileNums[1][i]].getD())^2;
			runningCount = runningCount + (allPieceArray[quadTileNums[1][i]].getC() + allPieceArray[quadTileNums[2][i]].getA())^2;
			runningCount = runningCount + (allPieceArray[quadTileNums[2][i]].getD() + allPieceArray[quadTileNums[3][i]].getB())^2;
			runningCount = runningCount + (allPieceArray[quadTileNums[3][i]].getA() + allPieceArray[quadTileNums[0][i]].getC())^2;
		}
		//System.out.println(runningCount);
	}
	
	public static  void testHalves(){
		int runningCount = 0;
		for(int i = 0;i<halfTileNums.length;i++){
			runningCount = runningCount + (allPieceArray[halfTileNums[0][i]].getB() + allPieceArray[halfTileNums[1][i]].getD())^2;
			runningCount = runningCount + (allPieceArray[halfTileNums[1][i]].getB() + allPieceArray[halfTileNums[2][i]].getD())^2;
			runningCount = runningCount + (allPieceArray[halfTileNums[2][i]].getB() + allPieceArray[halfTileNums[3][i]].getD())^2;
			runningCount = runningCount + (allPieceArray[halfTileNums[3][i]].getC() + allPieceArray[halfTileNums[7][i]].getA())^2;
			runningCount = runningCount + (allPieceArray[halfTileNums[7][i]].getD() + allPieceArray[halfTileNums[6][i]].getB())^2;
			runningCount = runningCount + (allPieceArray[halfTileNums[6][i]].getD() + allPieceArray[halfTileNums[5][i]].getB())^2;
			runningCount = runningCount + (allPieceArray[halfTileNums[5][i]].getD() + allPieceArray[halfTileNums[4][i]].getB())^2;
			runningCount = runningCount + (allPieceArray[halfTileNums[4][i]].getA() + allPieceArray[halfTileNums[0][i]].getC())^2;
		}
		//System.out.println(runningCount);
	}
	
	public static int getSol(){
		boolean complete = false;
		int solNum = -1;
		Scanner call = new Scanner(System.in);
		
		while(complete == false){
			System.out.println("Enter a solution number:");
			String input = call.nextLine();
			
			try {
				if (0<Integer.valueOf(input)&& Integer.valueOf(input)<solutionCount + 1){
					solNum = Integer.valueOf(input);
					complete = true;
				}
				if (Integer.valueOf(input).equals(-1)){
					return -1;
				}
			} catch(Exception e) {
				System.out.println("Please choose a number between 0 and " + solutionCount +":");
				System.out.println(" ");
			}
		}
		return solNum;
	}
	
	public static String numEdit1(int num){
		num += 4;
		int edit = (int)(num/4);
		if (edit > 9){
			return Integer.toString(edit);
		} else {
			String numEdit = "0" + Integer.toString(edit);
			return numEdit;
		}
	}
	
	public static String numEdit2(int num){
		if (num < 0){
			return Integer.toString(num);
		} else {
			String numEdit = " " + Integer.toString(num);
			return numEdit;
		}
	}
	
	public static void displaySol(int solNum){
		int half1 = halfSols[solNum-1][0];
		int half2 = halfSols[solNum-1][1];
		int[][] solArray = new int[4][4];
		
		solArray[0][0] = halfTileNums[0][half1];
		solArray[1][0] = halfTileNums[1][half1];
		solArray[2][0] = halfTileNums[2][half1];
		solArray[3][0] = halfTileNums[3][half1];
		solArray[0][1] = halfTileNums[4][half1];
		solArray[1][1] = halfTileNums[5][half1];
		solArray[2][1] = halfTileNums[6][half1];
		solArray[3][1] = halfTileNums[7][half1];
		solArray[0][2] = halfTileNums[0][half2];
		solArray[1][2] = halfTileNums[1][half2];
		solArray[2][2] = halfTileNums[2][half2];
		solArray[3][2] = halfTileNums[3][half2];
		solArray[0][3] = halfTileNums[4][half2];
		solArray[1][3] = halfTileNums[5][half2];
		solArray[2][3] = halfTileNums[6][half2];
		solArray[3][3] = halfTileNums[7][half2];
		
		for (int i = 0;i<4;i++){
			System.out.println(" ");
			System.out.println("   " + numEdit2(allPieceArray[solArray[0][i]].getA()) + "        " + numEdit2(allPieceArray[solArray[1][i]].getA()) + "        " + numEdit2(allPieceArray[solArray[2][i]].getA()) + "        " + numEdit2(allPieceArray[solArray[3][i]].getA()));
			System.out.println(" ");
			System.out.println(numEdit2(allPieceArray[solArray[0][i]].getD()) + " " + numEdit1(solArray[0][i]) + " " + numEdit2(allPieceArray[solArray[0][i]].getB()) + "  " + numEdit2(allPieceArray[solArray[1][i]].getD()) + " " + numEdit1(solArray[1][i]) + " " + numEdit2(allPieceArray[solArray[1][i]].getB()) + "  " + numEdit2(allPieceArray[solArray[2][i]].getD()) + " " + numEdit1(solArray[2][i]) + " " + numEdit2(allPieceArray[solArray[2][i]].getB()) + "  " + numEdit2(allPieceArray[solArray[3][i]].getD()) + " " + numEdit1(solArray[3][i]) + " " + numEdit2(allPieceArray[solArray[3][i]].getB()));
			System.out.println(" ");
			System.out.println("   " + numEdit2(allPieceArray[solArray[0][i]].getC()) + "        " + numEdit2(allPieceArray[solArray[1][i]].getC()) + "        " + numEdit2(allPieceArray[solArray[2][i]].getC()) + "        " + numEdit2(allPieceArray[solArray[3][i]].getC()));
			System.out.println(" ");
		}
		
	}
	
	public static void main(String[] args){
		loadPieces();
		spinPieces();
		listMatches();
		
/* 		for (int i = 0;i<doubleCount;i++){
			System.out.println(dualTileNums[0][i] + "|" + dualTileNums[1][i]);
			System.out.println(" ");
		} */
		
		dualList = makeDuals();
		pairDuals(dualList);
		
		//System.out.println(dualList[18].getA() + " " + dualList[18].getB() + " " + dualList[18].getC() + " " + dualList[18].getD());
		
		//System.out.print(quadTileCount);
		//System.out.print(quadTileNums[0][565]+ ", " + quadTileNums[1][565]+ ", " + quadTileNums[2][565]+ ", " + quadTileNums[3][565]);
		
		
/* 		for (int i = 0;i<7;i++){
			for(int j = 0;j<4;j++){
				System.out.println(quadTileNums[j][i*37 + 232]);
				System.out.println(" ");
			}
			System.out.println(" | ");
		} */
		
		
		pairQuads();
		
		System.out.println(halfTileCount);
		



		
		/* System.out.println("Quad Tile 453: " + quadTileNums[2][452]);
		System.out.println("Quad Tile 1820: " + quadTileNums[2][1819]);
		
		int[] quad1 = new int[4];
		int[] quad2 = new int[4];		
		for (int i = 0; i<4;i++){
			quad1[i] = quadTileNums[i][453];
			quad2[i] = quadTileNums[i][1820];
		}
		
		System.out.println(allPieceArray[quad1[1]].getB() + allPieceArray[quad2[0]].getD());
		System.out.println(allPieceArray[quad1[2]].getB() + allPieceArray[quad2[3]].getD());
	
		System.out.println(" "); */
		//testQuads();
		//testHalves();
		
/* 		for(int j = 0;j<8;j++){
				System.out.println("Half 49754, " + j+ " : " + halfTileNums[j][49754]);
		}
		
		System.out.println(" ");
		
		for(int l = 0;l<8;l++){
				System.out.println("Half 73628, " + l+ " : " + halfTileNums[l][73628]);
		} */
		
		
		
		
		
		pairHalves();
		
		boolean exit = false;
		while(exit == false){
			int num = getSol();
			if (num != -1){
				displaySol(num);
			} else {
				exit = true;
			}	
		}
			
			
			
/* 		if(sameHalfChecker(9256,1508)){
			System.out.println("These pieces are different");
		} else {
			System.out.println("They're the same");
		} */
	}
}